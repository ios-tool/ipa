<?php

namespace app\index\controller;

use app\common\controller\Frontend;
use think\Db;
class Api
{
    public function list()
   
    {
    	
     if (isset($_POST['udid']) && isset($_POST['code'])){
		$udid = $_POST['udid'];
		$code = $_POST['code'];
		$istime = time();
		
        $UID_lang_1 = '请先获取设备UDID';
        $UID_lang_2 = '解锁成功';
        $UID_lang_3 = '解锁码已到期失效';
        $UID_lang_4 = '解锁码已被使用';
        $UID_lang_5 = '解锁码不存在';
        /*
        // Remove comments if you need English
        $UID_lang_1 = 'Please first obtain the device UDID';
        $UID_lang_2 = 'unlocked success';
        $UID_lang_3 = 'Code Expired';
        $UID_lang_4 = 'Code It has been used';
        $UID_lang_5 = 'Code does not exist';
        */
	
 
    if (strlen($udid) != 25 && strlen($udid) != 40) {return json(['data'=>'0','msg'=>$UID_lang_1]);}
    
       $iskey = Db::table('fa_config')->where('name','identifier')->select();

       $key = md5($iskey[0]['value'].$udid);
    
    
	    $isudid = Db::table('fa_kami')->where('udid',$udid)->order('id desc')->select();
    if($isudid){
    	if($isudid[0]['endtime'] > $istime){
    	echo  '{"data":"'.$key.'","msg":"'.$UID_lang_2.'"}';
    	exit;
      }	
    }
		   
		
		$iscode = Db::table('fa_kami')->where('kami',$code)->order('id desc')->select();
		
			if($iscode){
                  $codeis = $iscode[0];
				if($codeis['status'] == 0){
					if($codeis['type'] == 1){  $endtm = $istime+(86400*30); }
					if($codeis['type'] == 2){  $endtm = $istime+(86400*30*3); }
					if($codeis['type'] == 3){  $endtm = $istime+(86400*30*12); }
        Db::table('fa_kami')->where('kami', $code)->update(array('udid'=>$udid, 'usetime'=>$istime, 'endtime'=>$endtm, 'status'=>1));
					echo  '{"data":"'.$key.'","msg":"'.$UID_lang_2.'"}';exit;
				}else{
					if($codeis['udid'] == $udid && $codeis['endtime'] < $istime){
						return json(['data'=>'0','msg'=>$UID_lang_3]);
					}
                    return json(['data'=>'0','msg'=>$UID_lang_4]);
				}
			}else{
				return json(['data'=>'0','msg'=>$UID_lang_5]);
			}
         }else{
		    return json(['data'=>'0','msg'=>'0']);	
      }
    
    }

}