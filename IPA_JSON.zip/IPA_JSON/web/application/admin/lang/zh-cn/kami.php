<?php

return [
    'Id'      => 'ID',
    'CODE'    => '卡密',
    'UDID'    => '设备UDID',
    'status'      => '是否激活',
    'Addtime' => '生成时间',
    'Usetime' => '使用时间',
    'Endtime' => '到期时间',
    'type'    => '卡密类型'
];
