<?php

return array (
  'name' => '魔力签源',
  'sourceicon' => 'https://ios-tool.com/apps.png',
  'identifier' => 'abc123',
  'jsonkey' => '1',
  'jsonhtml' => '1',
  'unlockURL' => '',
  'payURL' => '',
  'message' => '温馨提示：JSON源，魔力签软件源。',
  'version' => '1.1',
  'md5' => '7fc3b0ab217a2900f7dd6cb51421e7c2',
  'languages' => 
  array (
  ),
  'timezone' => 'Asia/Shanghai',
  'forbiddenip' => '',
  'fixedpage' => 'category',
  'categorytype' => 
  array (
    'default' => 'default',
  ),
  'configgroup' => 
  array (
    'basic' => 'Basic',
  ),
  'mail_type' => '1',
  'mail_smtp_host' => 'smtp.qq.com',
  'mail_smtp_port' => '465',
  'mail_smtp_user' => '10000',
  'mail_verify_type' => '2',
  'mail_from' => '10000@qq.com',
  'mail_smtp_pass' => 'password',
);