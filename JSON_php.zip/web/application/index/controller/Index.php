<?php

namespace app\index\controller;

use app\common\controller\Frontend;
use think\Db;
use think\Lang;

class Index extends Frontend
{

    protected $noNeedLogin = '*';
    protected $noNeedRight = '*';
    protected $layout = '';

    public function index()
    {


    if ( !empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off') {
        $http443 = 'https://';
      } elseif ( isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https' ) {
        $http443 = 'https://';
      } elseif ( !empty($_SERVER['HTTP_FRONT_END_HTTPS']) && strtolower($_SERVER['HTTP_FRONT_END_HTTPS']) !== 'off') {
        $http443 = 'https://';
      }else{
      	$http443 = 'http://';
    }
    
				$config = Db::table('fa_config')->select();
				if(empty($config)) return json(['code'=>0,'msg'=>'暂无站点数据']);
				$list = Db::table('fa_category')->where('status','normal')->order('weigh desc')->select();
				if(empty($list)) return json(['code'=>0,'msg'=>'暂无app数据']);
				$data = [];
				
				foreach ($list as $key=>$val)
				{
					$data[$key]['name'] = $val['name'];
					$data[$key]['version'] = $val['nickname'];
					$data[$key]['versionDate'] = date('Y-m-d H:i:s',$val['updatetime']);
					$data[$key]['localizedDescription'] = str_replace("\\n",'OKABC',$val['description']);
					$data[$key]['isNeedlock'] = $val['auth'];
					$data[$key]['downloadURL'] = $val['ipaurl'];
				//	$data[$key]['isLanZouCloud'] = $val['flag'];
					$data[$key]['iconURL'] = $val['image'];
					$data[$key]['appType'] = $val['flag'];
					$data[$key]['size'] = $val['size'];
				}
				
				foreach ($config as $key=>$val)
				{
					if($val['name'] == 'name') $info['name'] = $val['value'];
					if($val['name'] == 'message') $info['message'] = $val['value'];
					if($val['name'] == 'identifier') $info['identifier'] = $val['value'];
					if($val['name'] == 'sourceURL') $info['sourceURL'] = $val['value'];
					if($val['name'] == 'sourceicon') $info['sourceicon'] = $val['value'];
					if($val['name'] == 'payURL') $info['payURL'] = $val['value'];
					if($val['name'] == 'unlockURL') $info['unlockURL'] = $val['value'];
					if($val['name'] == 'jsonkey') $jsonssl = $val['value'];
					if($val['name'] == 'jsonhtml') $jsonhtml = $val['value'];
					if($val['name'] == 'md5') $jsonmd5 = $val['value'];
				}
				
				
				
				if($info['unlockURL'] == ''){
					$info['unlockURL'] = $http443.$_SERVER['HTTP_HOST'].'/api';
				}
				  $arrinfo = [
					'title'=>$info['name'],
					'caption'=>$info['message'],
					'date'=>date('Y',time()),
					'tintColor'=>'10b6ff',
					'isUnlock'=>'1',
					'imageURL'=>$info['sourceicon'],
					'key'=>$info['identifier'],
					'pay'=>$info['payURL'],
					'url'=>$info['unlockURL']
					];
					
					
					$arr = [
				    'news'=>$arrinfo,
					'apps'=>$data
					];
					
					
				$json = json_encode($arr,320);
				$jsonStr  = str_replace('OKABC', '\r\n', $json);
				
			if ($jsonhtml){	
			     $http_ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '' ; 
                   if (strpos($http_ua, 'magicdebSign') !== false or strpos($http_ua, 'magicTwoSign') !== false or strpos($http_ua, 'magicsign') !== false or strpos($http_ua, 'NewSign') !== false or strpos($http_ua, 'Profile') !== false) {
                       }else{
                       	      $vtitle = $info['name'];
			                  $jsurl = $http443.$_SERVER['HTTP_HOST'];
			                  
			              $this->view->assign('vtitle', $vtitle);
			              $this->view->assign('jsurl', $jsurl);
                         return $this->view->fetch();
                         exit;
                   }
			}
			
				if ($jsonssl){
					if(md5($jsonStr) == $jsonmd5){
						 $strjson = file_get_contents(APP_PATH . 'index/controller' . DS . 'json.txt'); 
                         return $strjson; //加密过直接读取
					   }else{

					   	   $url = 'https://sign.iostool.pro/json/jsonssl.php';
					   	   $dataJM = array('json' => $jsonStr);
                           $ch = curl_init();
                           curl_setopt($ch, CURLOPT_HEADER, 0);
                           curl_setopt($ch, CURLOPT_URL, $url);
                           curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                           curl_setopt($ch, CURLOPT_POST,true);   
                           curl_setopt($ch,CURLOPT_POSTFIELDS,$dataJM);
                           curl_setopt($ch, CURLOPT_TIMEOUT, 10); // 设置超时限制防止死循环
                           $result = curl_exec($ch);
                           curl_close($ch);
                           unset($ch);
                           $jsondata = json_decode($result, true);
                           //加密成功写入输出
                           if($jsondata['code'] == 1){
                           	$ssljson = '{"data":"'.$jsondata['json'].'"}';
                           	file_put_contents(APP_PATH . 'index/controller' . DS . 'json.txt',
                                 $ssljson, true);
                            Db::table('fa_config')->where('name','md5')->update(array('value'=>md5($jsonStr)));
                           	 return $ssljson;
                               }else{
                             return $jsonStr; //加密失败明文输出
                           }
	 
					}
				   
				}else{
					return $jsonStr; //明文输出模式
					
				}
				

    }

}
